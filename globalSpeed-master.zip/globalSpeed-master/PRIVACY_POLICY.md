
# Privacy Policy 
1. Global Speed does not collect any personal information. 
