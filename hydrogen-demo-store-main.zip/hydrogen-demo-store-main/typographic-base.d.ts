declare module 'typographic-base/index';
